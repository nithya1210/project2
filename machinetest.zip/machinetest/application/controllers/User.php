<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper(array('url'));
		$this->load->library('session');
		$this->load->model('Mymodel');
		
       
	}
      public function index(){
        $this->load->view('admin');
      }

      public function addproject(){
        $this->load->view('addproject');
       }
       public function addtask(){
        $data['projectname']= $this->Mymodel->getproject();
        $this->load->view('addtask',$data);
       }
       public function projectdetails(){
       $data['users'] = $this->Mymodel->projectdetails();
        $this->load->view('projectdetails',$data);
       }
       public function taskdetails(){
       $data['users'] = $this->Mymodel->taskdetails();
        $this->load->view('taskdetails',$data);
       }
        public function insertproject(){
     	
        $data=array(
          
          'projectname'=>$this->input->post('projectname'),
          'status'=>1

     	);
     	$result=$this->Mymodel->insertproject($data);
     	redirect('User/addproject');
     }
      public function inserttask(){
        $cur_date= date("y-m-d");
        $data=array(
          
          'project_fk'=>$this->input->post('projectname'),
           'task_name'=>$this->input->post('task_name'),
            'hours'=>$this->input->post('hours'),
            'date'=>$cur_date,
             'description'=>$this->input->post('description'),
          'status'=>1

      );
      $result=$this->Mymodel->inserttask($data);
      redirect('User/addtask');
     }
     public function gettask()
     {


      $data=$this->Mymodel->gettask();

      echo json_encode($data);

     }
     public function report()
     {
       $this->load->view('report');
     }
}
?>