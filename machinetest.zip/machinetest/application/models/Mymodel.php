<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mymodel extends CI_Model{

	public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
     public function insertproject($data){
        $this->db->insert('tbl_project', $data);
    }
       public function inserttask($data){
        $this->db->insert('tbl_task', $data);
    }
    public function getproject(){
      $this->db->select('*');
      $query=$this->db->get('tbl_project');
      return $query->result();


    }
    public function projectdetails(){
      $this->db->select('*');
      $this->db->where('status',1);
       
      $query=$this->db->get('tbl_project');
      return $query->result();


    }
    public function taskdetails(){
      $this->db->select('*');
      $this->db->where('tbl_task.status',1);
       $this->db->join('tbl_project','tbl_project.project_id=tbl_task.project_fk');
      $query=$this->db->get('tbl_task');
      return $query->result();


    }
    public function gettask(){
      $this->db->select('*');
      $this->db->from('tbl_project');
      $this->db->where('tbl_task.status',1);
       $this->db->join('tbl_task','tbl_project.project_id=tbl_task.project_fk');
      $query=$this->db->get();
      
      return $query->result();


    }

}
?>